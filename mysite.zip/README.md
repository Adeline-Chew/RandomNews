# RandomNews App

This is a web app built with Django as backend and ReactJS as frontend.

## Get started

1. Download the repository
2. Open terminal and run `pip install -r requirements.txt`
3. Then run `python manage.py runserver`
4. Open a new terminal session, cd *mysite-client*
5. Run `yarn start`

